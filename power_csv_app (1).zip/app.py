import streamlit as st
import pandas as pd
from tabs import filtering, sql_generator, visualization, data_quality, json_generator, support_chat
from utils.download import show_download_buttons

st.set_page_config(page_title="Power CSV", layout="wide")

def load_csv():
    st.sidebar.title("📁 Upload CSV")
    uploaded_file = st.sidebar.file_uploader("Choose a CSV file", type="csv")
    if uploaded_file:
        df = pd.read_csv(uploaded_file)
        st.sidebar.success("✅ File uploaded successfully!")
        return df
    else:
        st.sidebar.warning("⚠️ Please upload a CSV file to proceed.")
        st.stop()

def main():
    df = load_csv()
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
        "🧹 Data Filtering", "🧾 SQL Generator",
        "📊 Data Visualization", "✅ Data Quality",
        "🔧 JSON Generator", "💬 Support Chat"
    ])
    with tab1:
        filtering.display(df)
    with tab2:
        sql_generator.display(df)
    with tab3:
        visualization.display(df)
    with tab4:
        data_quality.display(df)
    with tab5:
        schema = json_generator.display(df)
    with tab6:
        support_chat.display(df)
    show_download_buttons(df, schema)

if __name__ == "__main__":
    main()
