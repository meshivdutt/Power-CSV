import streamlit as st
from io import BytesIO
import json

def show_download_buttons(df, schema):
    st.sidebar.title("⬇️ Download Options")

    buffer = BytesIO()
    df.to_csv(buffer, index=False)
    st.sidebar.download_button("Download CSV", buffer.getvalue(), file_name="data.csv", mime="text/csv")

    json_buffer = BytesIO()
    json_buffer.write(json.dumps(schema, indent=2).encode())
    st.sidebar.download_button("Download JSON", json_buffer.getvalue(), file_name="schema.json", mime="application/json")
