import streamlit as st
import json

def display(df):
    st.header("🔧 JSON Schema Generator")
    schema = [{"column": col, "dtype": str(dtype)} for col, dtype in zip(df.columns, df.dtypes)]
    st.json(schema)

    json_str = json.dumps(schema, indent=4)
    st.download_button("Download JSON Schema", json_str, file_name="schema.json", mime="application/json")
    return schema
