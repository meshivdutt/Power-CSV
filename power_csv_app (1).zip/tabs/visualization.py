import streamlit as st
import plotly.express as px

def display(df):
    st.header("📊 Data Visualization")
    chart_type = st.selectbox("Select chart type", ["Bar", "Pie", "Line", "Histogram"])
    x_axis = st.selectbox("X-axis", df.columns)
    y_axis = st.selectbox("Y-axis", df.columns)

    if chart_type == "Bar":
        fig = px.bar(df, x=x_axis, y=y_axis)
    elif chart_type == "Pie":
        fig = px.pie(df, names=x_axis, values=y_axis)
    elif chart_type == "Line":
        fig = px.line(df, x=x_axis, y=y_axis)
    elif chart_type == "Histogram":
        fig = px.histogram(df, x=x_axis)
    st.plotly_chart(fig, use_container_width=True)
