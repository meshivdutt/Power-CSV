import streamlit as st

def display(df):
    st.header("💬 Support Chat")
    question = st.text_input("💡 Type your question here")
    if question:
        if any(word in question.lower() for word in df.columns.str.lower()):
            st.success("📄 Answer from uploaded file:")
            st.write("This seems related to your file. Please explore it using filters and summaries above.")
        else:
            st.info("🤖 Fetching from Amazon Bedrock...")
            st.write("You can integrate Bedrock here using boto3 and Titan/GPT or Claude models.")
            st.code("response = bedrock_runtime.invoke_model(...)", language="python")
            st.write("💡 Example response: 'This is a response generated using Amazon Bedrock.'")
