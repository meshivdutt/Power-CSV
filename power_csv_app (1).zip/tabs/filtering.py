import streamlit as st

def display(df):
    st.header("🧹 Data Filtering, Count & Duplicate Checks")
    st.dataframe(df.head(50))

    st.subheader("🔍 Filter Data")
    filter_col = st.selectbox("Select column to filter", df.columns)
    selected_val = st.selectbox("Select value", df[filter_col].unique())
    filtered_df = df[df[filter_col] == selected_val]
    st.write(f"Filtered Rows: {len(filtered_df)}")
    st.dataframe(filtered_df)

    st.subheader("🔁 Duplicate Check")
    dup_cols = st.multiselect("Select columns to check duplicates", df.columns)
    if dup_cols:
        dups = df[df.duplicated(subset=dup_cols)]
        st.write(f"Duplicate Rows Found: {len(dups)}")
        st.dataframe(dups)
