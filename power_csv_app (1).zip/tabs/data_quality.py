import streamlit as st
import pandas as pd

def display(df):
    st.header("✅ Data Quality Checks")
    st.write("🔹 Total Rows:", len(df))
    st.write("🔹 Total Columns:", len(df.columns))

    st.subheader("🧪 Null Value Check")
    nulls = df.isnull().sum()
    st.dataframe(nulls[nulls > 0])

    st.subheader("📏 Data Type Check")
    dtypes = pd.DataFrame(df.dtypes, columns=["Data Type"])
    st.dataframe(dtypes)
