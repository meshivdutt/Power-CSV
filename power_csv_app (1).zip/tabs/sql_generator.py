import streamlit as st

def display(df):
    st.header("🧾 SQL Generator")
    table_name = st.text_input("Enter table name", "my_table")
    sql_query = f"SELECT {', '.join(df.columns)} FROM {table_name};"
    st.code(sql_query, language="sql")
    st.subheader("📄 Data Preview")
    st.dataframe(df.head(10))
